DROP INDEX "#__contentitem_tag_map_idx_tag";
DROP INDEX "#__contentitem_tag_map_idx_type";
